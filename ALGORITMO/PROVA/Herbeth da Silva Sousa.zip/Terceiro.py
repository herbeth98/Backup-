quantPeixes= int(input("Insira a quantidade de Peixes:"))
pesoTotalPeixes = float(input("Insira o PESO TOTAL da pesca em KG:"))

if pesoTotalPeixes > 50:
    excesso= (pesoTotalPeixes - 50)
    multa = (excesso * 4)
    print("Quantidade de peixes: %s ; Peso total da pesca em KG: %s; Peso Excedente: %s Kg; Multa: R$ %s" %(quantPeixes,pesoTotalPeixes,excesso,multa))  

else:
    print("Quantidade de peixes: %s ; Peso total da pesca: %s Kg" %(quantPeixes,pesoTotalPeixes))